import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { useAuth } from "@/app/providers/AuthProvider";
import { Avatar } from "@/shared/ui/Avatar";
import { SPRING, stagger, riseIn } from "@/shared/ui/motion";
import { rankFor } from "@/features/play/rank";
import { RankBadge } from "@/features/play/RankBadge";
import { useLeaderboard, type Standing } from "./useLeaderboard";

/** 2nd, 1st, 3rd — the order they stand in, not the order they finished. */
const PODIUM_ORDER = [1, 0, 2];
const PLINTH = [
  { h: 96, bg: "bg-pop" },      // 1st
  { h: 68, bg: "bg-sand" },     // 2nd
  { h: 52, bg: "bg-surface" },  // 3rd
];

function Podium({ top, meId }: { top: Standing[]; meId?: string }) {
  return (
    <div className="flex items-end justify-center gap-2.5 sm:gap-4 mt-6 border-b-[3px] border-ink">
      {PODIUM_ORDER.map((i, slot) => {
        const p = top[i];
        if (!p) return null;
        const first = i === 0;
        return (
          <motion.div key={p.id} className="flex-1 max-w-[140px] text-center"
            initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }}
            transition={{ ...SPRING, delay: 0.1 + slot * 0.09 }}>
            <motion.div
              initial={{ scale: 0.4, rotate: -18 }} animate={{ scale: 1, rotate: 0 }}
              transition={{ type: "spring", stiffness: 300, damping: 15, delay: 0.24 + slot * 0.09 }}
              className="grid place-items-center">
              <Avatar id={p.id} name={p.username} size={first ? 60 : 48} />
            </motion.div>
            <p className={`mt-2 font-display font-semibold truncate px-1
              ${first ? "text-[15px]" : "text-[13px]"} ${p.id === meId ? "text-picto" : ""}`}>
              {p.username}
            </p>
            <p className="text-[13px] font-bold text-soft tabular-nums">{p.answered}</p>
            {/* The plinths are what make it a podium rather than three avatars in
                a row, so they carry the numeral and the height difference. */}
            <motion.div
              className={`piece ${PLINTH[i].bg} mt-2 grid place-items-center rounded-b-none`}
              style={{ boxShadow: "none" }}
              initial={{ height: 0 }} animate={{ height: PLINTH[i].h }}
              transition={{ ...SPRING, delay: 0.16 + slot * 0.09 }}>
              <span className="font-display text-3xl font-semibold">{i + 1}</span>
            </motion.div>
          </motion.div>
        );
      })}
    </div>
  );
}

function Row({ p, meId }: { p: Standing; meId?: string }) {
  const me = p.id === meId;
  const rank = rankFor(p.answered).current;
  return (
    <div className={`piece press flex items-center gap-3 px-3 py-2.5 ${me ? "bg-pop" : ""}`}>
      <span className="w-7 shrink-0 text-center font-display text-lg font-semibold tabular-nums text-soft">
        {p.position}
      </span>
      <Avatar id={p.id} name={p.username} size={36} />
      <span className="min-w-0 flex-1">
        <span className="block font-bold text-[15px] truncate">
          {p.username}{me && <span className="text-soft font-black text-[12px] uppercase tracking-widest ml-1.5">you</span>}
        </span>
        <span className="block text-[13px] font-bold text-soft tabular-nums">
          {p.answered} answered
          {p.answered > 0 && ` · ${Math.round((p.correct / p.answered) * 100)}%`}
          {p.streak > 1 && ` · ${p.streak}-day streak`}
        </span>
      </span>
      <RankBadge rank={rank.key} size={30} />
    </div>
  );
}

/** The fade is what stops a floating bar reading as a row that got cut in half. */
function StickyBar({ children }: { children: React.ReactNode }) {
  return (
    <div className="fixed inset-x-0 bottom-[62px] sm:bottom-0 z-20 px-4 pt-10 pb-3.5 pointer-events-none"
      style={{ background: "linear-gradient(to top, var(--color-paper) 62%, transparent)" }}>
      <div className="max-w-3xl mx-auto pointer-events-auto">{children}</div>
    </div>
  );
}

export function LeaderboardPage() {
  const { user, offline } = useAuth();
  const { rows, you, loading } = useLeaderboard(user?.id);

  if (offline) {
    return (
      <div className="piece p-6">
        <h1 className="font-display text-2xl font-semibold">Leaderboard</h1>
        <p className="text-sm text-soft font-semibold mt-2">
          There is no backend configured, so there is nobody to rank. Add Supabase keys and it fills in.
        </p>
      </div>
    );
  }

  const top = rows.slice(0, 3);
  const rest = rows.length >= 3 ? rows.slice(3) : rows;
  const youOnPage = !!you && rows.some((r) => r.id === you.id);

  return (
    <motion.div variants={stagger(0.07)} initial="hidden" animate="show" className="pb-24">
      <motion.h1 variants={riseIn} className="font-display text-[34px] leading-none font-semibold">
        Leaderboard
      </motion.h1>
      <motion.p variants={riseIn} className="text-soft text-sm font-semibold mt-2">
        Ranked by questions answered — turning up beats being clever.
      </motion.p>

      {loading ? (
        <div className="mt-6 space-y-2">
          {Array.from({ length: 5 }, (_, i) => (
            <div key={i} className="piece h-[62px] animate-pulse opacity-40" />
          ))}
        </div>
      ) : rows.length === 0 ? (
        <div className="piece p-6 mt-6 text-center">
          <p className="font-display text-xl font-semibold">Nobody has played yet.</p>
          <p className="text-sm text-soft font-semibold mt-1">
            Answer one question and the top spot is yours.
          </p>
          <Link to="/trivia" className="piece press inline-block mt-4 px-5 py-3 bg-pop font-display font-semibold">
            Start a round
          </Link>
        </div>
      ) : (
        <>
          {rows.length >= 3 && <Podium top={top} meId={user?.id} />}
          <div className="mt-4 space-y-2">
            {rest.map((p, i) => (
              <motion.div key={p.id}
                initial={{ opacity: 0, x: -12 }} animate={{ opacity: 1, x: 0 }}
                transition={{ ...SPRING, delay: 0.35 + i * 0.035 }}>
                <Row p={p} meId={user?.id} />
              </motion.div>
            ))}
          </div>
        </>
      )}

      {/* Being 214th is still information. Without this row the page just stops
          before it reaches you, which reads as "you are not on here". */}
      {!loading && you && !youOnPage && (
        <StickyBar><Row p={you} meId={user?.id} /></StickyBar>
      )}
      {!loading && !user && rows.length > 0 && (
        <StickyBar>
          <Link to="/profile" className="piece press block bg-pop px-4 py-3 text-center font-display font-semibold">
            Sign in to take a place on this list →
          </Link>
        </StickyBar>
      )}
    </motion.div>
  );
}
