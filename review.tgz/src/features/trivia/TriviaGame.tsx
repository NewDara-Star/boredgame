import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { useRound } from "@/features/play/useRound";
import { CategoryBar } from "@/features/play/CategoryBar";
import { readFilter, writeFilter } from "@/features/play/filters";
import { shuffle } from "@/features/play/content";
import { Hud, Reveal, Summary, Burst } from "@/features/play/RoundChrome";
import { SPRING, stagger, riseIn } from "@/shared/ui/motion";

const SHAPES = ["▲", "◆", "●", "■"];
const HUES = ["#FF5A1F", "#2B4BFF", "#FFD028", "#10A04E"];

export function TriviaGame() {
  const [cats, setCats] = useState<string[]>(() => readFilter("trivia"));
  const r = useRound("trivia", 10, cats);
  const chooseCats = (next: string[]) => { setCats(next); writeFilter("trivia", next); };
  const filterBar = (
    <CategoryBar categories={r.categories} selected={cats} onChange={chooseCats} />
  );

  // Shuffle once per question, not per render, or the options jump around.
  const options = useMemo(
    () => (r.current?.choices ? shuffle(r.current.choices) : []),
    [r.current?.id] // eslint-disable-line react-hooks/exhaustive-deps
  );

  /**
   * 50/50 rather than a written hint. On four options a letter count usually
   * identifies the answer outright, so an authored hint is either useless or a
   * giveaway; burning two wrong options is a real cost/benefit choice instead.
   */
  const burned = useMemo(() => {
    if (!r.current || r.hintsUsed === 0) return new Set<string>();
    const wrong = options.filter((o) => o !== r.current!.answer);
    return new Set(shuffle(wrong).slice(0, 2));
  }, [r.current?.id, r.hintsUsed]); // eslint-disable-line react-hooks/exhaustive-deps

  if (r.phase === "loading") return <>{filterBar}<p className="text-soft font-bold">Loading questions…</p></>;
  if (r.phase === "empty") return (
    <>{filterBar}<p className="text-soft font-bold">
      {cats.length ? "Nothing live in those categories yet — widen the filter." : "No trivia is live yet."}
    </p></>
  );

  if (r.phase === "done") {
    return (
      <>
      {filterBar}
      <Summary score={r.score} results={r.results} outcome={r.outcome} onAgain={r.restart}>
        <div className="grid gap-2.5">
          {r.results.map((res, i) => (
            <motion.div key={i}
              initial={{ opacity: 0, x: -14 }} animate={{ opacity: 1, x: 0 }}
              transition={{ ...SPRING, delay: 0.3 + i * 0.04 }}
              className={`piece p-3 ${res.correct ? "bg-surface" : "bg-sand"}`}>
              <p className="text-sm font-bold">{res.item.prompt}</p>
              <p className="text-xs mt-1 font-bold">
                {res.correct
                  ? <span className="text-good">✓ {res.item.answer}</span>
                  : <><span className="text-bad line-through">{res.given}</span>
                      <span className="text-good"> → {res.item.answer}</span></>}
              </p>
            </motion.div>
          ))}
        </div>
      </Summary>
      </>
    );
  }

  const item = r.current;
  if (!item) return null;
  const revealed = r.phase === "revealed";

  return (
    <div>
      {filterBar}
      <Hud index={r.index} total={r.items.length} score={r.score} streak={r.streak} accent="#2B4BFF" />

      <AnimatePresence mode="wait">
        <motion.div key={item.id}
          initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -16 }} transition={SPRING} className="relative">
          <Burst show={revealed && !!r.last?.correct} />

          <span className="inline-block mt-5 text-[12px] font-black uppercase tracking-widest
            bg-trivia text-surface rounded-full px-2.5 py-1">
            {item.category} · {item.difficulty}
          </span>
          <h2 className="mt-3 font-display text-[26px] leading-tight font-semibold text-balance">
            {item.prompt}
          </h2>

          <motion.div variants={stagger(0.055, 0.1)} initial="hidden" animate="show"
            className="mt-5 grid gap-2.5">
            {options.map((opt, i) => {
              const isBurned = burned.has(opt);
              const isAnswer = opt === item.answer;
              const isMine = revealed && r.last?.given === opt;
              const bg = isBurned && !revealed ? "bg-surface opacity-25 line-through"
                : !revealed ? "bg-surface"
                : isAnswer ? "bg-good text-surface"
                : isMine ? "bg-bad text-surface" : "bg-surface opacity-45";
              return (
                <motion.button key={opt} variants={riseIn}
                  disabled={revealed || isBurned} onClick={() => r.submit(opt)}
                  whileTap={revealed ? undefined : { scale: 0.97 }}
                  className={`piece ${revealed ? "" : "press"} flex items-center gap-3 text-left px-4 py-4 ${bg}`}>
                  <span aria-hidden className="text-base shrink-0"
                    style={{ color: revealed && (isAnswer || isMine) ? "currentColor" : HUES[i % 4] }}>
                    {SHAPES[i % 4]}
                  </span>
                  <span className="text-[15px] font-bold">{opt}</span>
                </motion.button>
              );
            })}
          </motion.div>
        </motion.div>
      </AnimatePresence>

      {r.phase === "playing" ? (
        r.hintsUsed === 0 && (
          <button onClick={r.useHint}
            className="piece press mt-4 text-xs font-black uppercase tracking-wider px-3 py-2 rounded-xl bg-pop">
            50 / 50 — burn two wrong answers · −100
          </button>
        )
      ) : (
        <Reveal correct={r.last!.correct} near={false} answer={item.answer}
          gained={r.last!.gained} onNext={r.next} isLast={r.index + 1 >= r.items.length}
          explanation={item.explanation} />
      )}
    </div>
  );
}
